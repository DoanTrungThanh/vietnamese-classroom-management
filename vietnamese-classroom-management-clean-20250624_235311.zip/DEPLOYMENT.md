# 🚀 Quick Deployment Instructions

## Render.com (Recommended - Free)

1. **Fork this repository** to your GitHub account
2. **Go to** [Render.com](https://render.com) and sign up with GitHub
3. **Create Web Service** from your repository
4. **Configure**:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python run.py`
5. **Create PostgreSQL database** on Render
6. **Add Environment Variables** (see .env.example)
7. **Deploy** and access your app!

## Default Login
- Username: `admin`
- Password: `admin123`

## Documentation
- [Detailed Guide](RENDER_STEP_BY_STEP.md)
- [Quick Deploy](DEPLOY_NOW.md)

**🎉 Your Vietnamese Classroom Management System will be live in 10 minutes!**
