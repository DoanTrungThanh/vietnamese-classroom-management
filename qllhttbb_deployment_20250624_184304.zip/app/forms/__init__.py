from .auth_forms import LoginForm, RegistrationForm
from .class_forms import ClassForm, StudentForm
from .schedule_forms import ScheduleForm, AttendanceForm
from .event_forms import EventForm
from .finance_forms import FinanceForm
